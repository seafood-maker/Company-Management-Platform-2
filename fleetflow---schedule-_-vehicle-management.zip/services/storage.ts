
import { Schedule, Vehicle } from '../types';
import { INITIAL_SCHEDULES, MOCK_VEHICLES } from '../constants';

const STORAGE_KEYS = {
  SCHEDULES: 'fleetflow_schedules',
  VEHICLES: 'fleetflow_vehicles'
};

export const storage = {
  getSchedules: (): Schedule[] => {
    const data = localStorage.getItem(STORAGE_KEYS.SCHEDULES);
    return data ? JSON.parse(data) : INITIAL_SCHEDULES;
  },
  saveSchedules: (schedules: Schedule[]) => {
    localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(schedules));
  },
  getVehicles: (): Vehicle[] => {
    const data = localStorage.getItem(STORAGE_KEYS.VEHICLES);
    return data ? JSON.parse(data) : MOCK_VEHICLES;
  },
  saveVehicles: (vehicles: Vehicle[]) => {
    localStorage.setItem(STORAGE_KEYS.VEHICLES, JSON.stringify(vehicles));
  }
};

export const checkCollision = (
  newSchedule: Partial<Schedule>,
  existingSchedules: Schedule[]
): string | null => {
  if (!newSchedule.vehicleId || newSchedule.vehicleId === 'none') return null;

  const { date, startTime, endTime, vehicleId, id } = newSchedule;
  
  const overlapping = existingSchedules.find(s => {
    // Skip checking against itself if editing
    if (s.id === id) return false;
    
    // Must be same vehicle and same date
    if (s.vehicleId !== vehicleId || s.date !== date) return false;

    // Time overlap logic: (StartA < EndB) && (EndA > StartB)
    const startA = startTime!;
    const endA = endTime!;
    const startB = s.startTime;
    const endB = s.endTime;

    return (startA < endB) && (endA > startB);
  });

  if (overlapping) {
    return `車輛衝突！該時段 (${overlapping.startTime} - ${overlapping.endTime}) 已被 ${overlapping.userName} 預約（目的地：${overlapping.destination}）。`;
  }

  return null;
};
